﻿namespace BugDetectorGP.Dto
{
    public class LogOutUser
    {
        public string? Token {  get; set; }
    }
}
