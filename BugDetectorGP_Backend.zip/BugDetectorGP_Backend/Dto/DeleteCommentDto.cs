﻿namespace BugDetectorGP.Dto
{
    public class DeleteCommentDto
    {
        public int BlogId { get; set; }
        public int CommentId { get; set; }
    }
}
