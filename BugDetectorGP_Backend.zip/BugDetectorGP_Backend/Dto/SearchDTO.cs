﻿namespace BugDetectorGP.Dto
{
    public class SearchDTO
    {
        public string Words { get; set; }
    }
}
