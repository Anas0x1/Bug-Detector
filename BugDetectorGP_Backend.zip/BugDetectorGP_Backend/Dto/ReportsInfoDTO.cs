﻿namespace BugDetectorGP.Dto
{
    public class ReportsInfoDTO
    {
        public int ReportId { get; set; }
        public string Targit {  get; set; }
        public string Type { get; set; }
        public DateTime DateTime { get; set; }

    }
}
