﻿namespace BugDetectorGP.Dto
{
    public class ReportDto
    {
        public string title { get; set; }
        public string details { get; set; }
        public string output { get; set; }
    }
}
