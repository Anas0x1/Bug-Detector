﻿namespace BugDetectorGP.Dto
{
    public class CommentDTO
    {
        public int BlogId { get; set; }
        public string Comment { get; set; }

    }
}
