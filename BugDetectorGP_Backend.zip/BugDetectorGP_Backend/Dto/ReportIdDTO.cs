﻿namespace BugDetectorGP.Dto
{
    public class ReportIdDTO
    {
        public int Id { get; set; }
    }
}
